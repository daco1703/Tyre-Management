# Shepards Tyre Management 1.10.0 — iOS project and shared source

This archive contains the shared website/API/Android/iOS source needed to rebuild the app. It excludes dependencies, compiled builds, database records, environment variables and signing credentials.

Use Node 24: npm ci; npm run check:versions; npm run ios:sync. On a Mac with Xcode, open ios/App/App.xcodeproj and select the App scheme. Swift Package Manager resolves native dependencies. See docs/RELEASING.md for unsigned simulator validation and optional signed-device IPA instructions. A source ZIP or simulator .app is not installable on an iPhone. A device IPA needs Apple signing and an appropriate provisioning profile; no IPA is supplied or implied by this source archive.

Use the existing Vercel API and private Neon database. Never include database URLs, certificates, profiles or live records in a release archive.

Build 12. See BUNDLE-MANIFEST.json and SHA256SUMS.txt for file verification.
