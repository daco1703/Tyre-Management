# Shepards Tyre Management 1.11.0 — web client

The dist folder contains the compiled shared React client. This archive does not contain a database or a working API server. Serve it with this app's Vercel API connected to the existing private Neon database; a static host alone cannot sign users in or save records. The full source and deployment instructions are in the matching ios-project-source ZIP. Do not replace or reset the live database when updating the client.

Build 14. This is not an APK, IPA or offline app. See BUNDLE-MANIFEST.json and SHA256SUMS.txt for file verification.
